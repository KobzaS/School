class Payroll extends Pay
{
    
    public double calc_PayRoll()
    {
        double netPay, grossPay, tax;
        grossPay = super.calc_PayRoll();
        //System.out.println(grossPay+ " afsdagf");
        

        tax = tax(grossPay);

        //System.out.println(tax);

        tax = 1 - tax;

        netPay = grossPay * tax;

        return netPay;
    }
}